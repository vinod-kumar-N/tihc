import React, { Fragment } from 'react';

import SignUpComp from '@Components/signupComp';

const SignUp = () => {
  return (
    <Fragment>
      <SignUpComp />
    </Fragment>
  );
};
  
  export default SignUp;