import React from "react";

const NotFound = () => {
  return <div>Not found page!</div>;
};

export default NotFound;
