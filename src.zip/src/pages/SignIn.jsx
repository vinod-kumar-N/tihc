import React, { Fragment } from 'react';

import SignUpComp from '@Components/signinComp';

const SignIn = () => {
  return (
    <Fragment>
      <SignUpComp />
    </Fragment>
  );
};

export default SignIn;
