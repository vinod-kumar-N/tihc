import React from "react";
import Header from "@Uilib/header";
import Footer from "@Uilib/footer";
import Businesss from '../components/businesss';
const business = () => {
  return (
    <div>
      <Header />
      <Businesss />
      <Footer />
    </div>
  );
};

export default business;
