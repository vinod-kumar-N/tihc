import React from 'react';
import './business.css';

const businesss  = () =>{
    return(
        <div  className="Business">
            <p>From Business Page</p>
        </div>
    )
}
export default businesss;