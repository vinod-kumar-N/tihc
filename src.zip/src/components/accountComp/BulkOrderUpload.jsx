import React from 'react'

export default function BulkOrderUpload() {
  return (
    <div>
      Bulk Order Upload
    </div>
  )
}
