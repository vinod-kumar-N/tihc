import React from 'react'

export default function navigateToSignUp() {
  return (
    <div>
      to signup page
    </div>
  )
}
