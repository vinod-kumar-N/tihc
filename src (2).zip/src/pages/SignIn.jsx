import React, { Fragment } from 'react';

import SigninComp from '@Components/signinComp';

const SignIn = () => {
  return (
    <Fragment>
      <SigninComp />
    </Fragment>
  );
};

export default SignIn;
