import React from "react";
import Header from "@Uilib/header";
import Footer from "@Uilib/footer";

const CopyWriting = () => {
  return (
    <div>
      <Header />
      CopyWriting
      <Footer />
    </div>
  );
};

export default CopyWriting;
