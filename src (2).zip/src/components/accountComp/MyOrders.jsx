import React from 'react'

export default function MyOrders() {
  return (
    <div>
      My Orders
    </div>
  )
}
