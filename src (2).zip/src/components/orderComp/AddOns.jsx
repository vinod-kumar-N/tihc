import React from 'react';

const AddOn = () => {
  return (
    <div>
      AddOn
    </div>
  );
};

export default AddOn;