import React from 'react';

const Confirmation = () =>{
  return (
    <div>
      Confirmation
    </div>
  );
}

export default Confirmation;