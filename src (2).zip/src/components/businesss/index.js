import React from 'react';
import './business.css';
import Banner from './BannerComp';

const businesss  = () =>{
    return(
        <div  className="Business">
            <Banner />
            <p>From Business Page</p>
        </div>
    )
}
export default businesss;